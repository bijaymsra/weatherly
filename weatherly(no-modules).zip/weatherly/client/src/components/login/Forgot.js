// import React, { useState } from 'react';
// import { useNavigate, useLocation } from 'react-router-dom';
// import axios from 'axios';
// import './Forgot.css';

// const ForgotPassword = () => {
//   const [code, setCode] = useState('');
//   const [message, setMessage] = useState('');
//   const [password, setPassword] = useState('');
//   const [isPasswordVisible, setIsPasswordVisible] = useState(false);
//   const [isDisable, setIsDisable] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);
//   const [isLoadingPass, setIsLoadingPass] = useState(false);
//   const [passwordVisible, setPasswordVisible] = useState(false);

//   const location = useLocation();
//   const email = location.state?.email || '';
//   const navigate = useNavigate();

//   const handleVerifyCode = async (e) => {
//     e.preventDefault();
//     setIsLoading(true);
//     setMessage('');

//     setTimeout(async () => {
//       try {
//         const response = await axios.post('http://localhost:5000/verify-code', { email, code });
//         setMessage(response.data.message);
//         if (response.status === 200) {
//           setIsPasswordVisible(true);
//           setIsDisable(true);
//         }
//       } catch (error) {
//         setMessage('Wrong OTP entered. Please try again.');
//       } finally {
//         setIsLoading(false);
//       }
//     }, 3000);
//   };

//   const resetPassword = async (e) => {
//     isLoadingPass(true);
//     e.preventDefault();

//     if (!email) {
//       alert('No email provided. Please try the password reset process again.');
//       return;
//     }

//     setIsLoading(true);

//     setTimeout(async () => {
//       try {
//         const response = await axios.post('http://localhost:5000/reset-password', { email, password });

//         if (response.status === 200) {
//           navigate('/login');
//         }
//       } catch (error) {
//         alert('Please check your details and try again.');
//       } finally {
//         setIsLoading(false);
//       }
//     }, 3000);
//   };

//   return (
//     <div className="forgot-container">
//       <form onSubmit={handleVerifyCode} className="otp-form">
//         <h1>Enter OTP to Verify Identity</h1>
//         <p>Please enter the code sent to your email.</p>
        
//         <label htmlFor="otp">Enter Code:</label>
//         <input
//           id="otp"
//           type="text"
//           value={code}
//           onChange={(e) => setCode(e.target.value)}
//           required
//           disabled={isDisable}
//         />
//         <button type="submit" disabled={isDisable || isLoading}>
//           {isLoading ? 'Verifying...' : 'Verify Identity'}
//         </button>
//         {message && <p className="message">{message}</p>}
//       </form>

//       {isPasswordVisible && (
//         <form onSubmit={resetPassword} className="password-form">
//           <label htmlFor="new-password">New Password:</label>
//           <div className="password-container">
//             <input
//               id="new-password"
//               type={passwordVisible ? 'text' : 'password'}
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//             <button
//               type="button"
//               className="password-toggle"
//               onClick={() => setPasswordVisible(!passwordVisible)}
//             >
//               {passwordVisible ? 'Hide' : 'Show'}
//             </button>
//           </div>
//           <button type="submit" disabled={isLoadingPass}>
//             {isLoadingPass ? 'Wait a moment...' : 'Save Password'}
//           </button>
//         </form>
//       )}
//     </div>
//   );
// };

// export default ForgotPassword;



import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './Forgot.css';

const ForgotPassword = () => {
  const [code, setCode] = useState('');
  const [message, setMessage] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isDisable, setIsDisable] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingPass, setIsLoadingPass] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false);

  const location = useLocation();
  const email = location.state?.email || '';
  const navigate = useNavigate();

  const handleVerifyCode = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage('');

    setTimeout(async () => {
      try {
        const response = await axios.post('http://localhost:5000/verify-code', { email, code });
        setMessage(response.data.message);
        if (response.status === 200) {
          setIsPasswordVisible(true);
          setIsDisable(true);
        }
      } catch (error) {
        setMessage('Invalid Otp entered');
      } finally {
        setIsLoading(false);
      }
    }, 3000);
  };

  const resetPassword = async (e) => {
    e.preventDefault();

    if (!email) {
      alert('No email provided. Please try the password reset process again.');
      return;
    }

    setIsLoadingPass(true);

    setTimeout(async () => {
      try {
        const response = await axios.post('http://localhost:5000/reset-password', { email, password });

        if (response.status === 200) {
          navigate('/login');
        }
      } catch (error) {
        alert('Please check your details and try again.');
      } finally {
        setIsLoadingPass(false);
      }
    }, 3000);
  };

  return (
    <div className="forgot-container">
      <form onSubmit={handleVerifyCode} className="otp-form">
        <h1>Enter OTP to Verify Identity</h1>
        <p>Please enter the Otp sent to your email.</p>
        
        <label htmlFor="otp">Enter Code:</label>
        <input
          id="otp"
          type="text"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          required
          disabled={isDisable}
        />
        <button type="submit" disabled={isDisable || isLoading}>
          {isLoading ? 'Verifying...' : 'Verify Identity'}
        </button>
        {message && <p className="message">{message}</p>}
      </form>

      {isPasswordVisible && (
        <form onSubmit={resetPassword} className="password-form">
          <label htmlFor="new-password">New Password:</label>
          <div className="password-container">
            <input
              id="new-password"
              type={passwordVisible ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="button"
              className="password-toggle"
              onClick={() => setPasswordVisible(!passwordVisible)}
            >
              {passwordVisible ? 'Hide' : 'Show'}
            </button>
          </div>
          <button type="submit" disabled={isLoadingPass}>
            {isLoadingPass ? 'Wait a moment...' : 'Save Password'}
          </button>
        </form>
      )}
    </div>
  );
};

export default ForgotPassword;
