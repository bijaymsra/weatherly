import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FaSun, FaMoon, FaCog, FaCloudSun } from 'react-icons/fa';
import './Dashboard.css';

function Dashboard() {
  const navigate = useNavigate();
  const [darkMode, setDarkMode] = useState(false);
  const [user, setUser] = useState('');


  useEffect(() => {

    axios.get('http://localhost:5000/api/session', { withCredentials: true })
      .then(response => {
        if (response.status === 200) {
          setUser(response.data.name);
          const savedDarkMode = localStorage.getItem('darkMode') === 'true';
          setDarkMode(savedDarkMode);
          document.body.classList.toggle('dark-mode', savedDarkMode);
        } else {
          throw new Error('Failed to fetch session data');
        }
      })
      .catch(error => {
        console.error('Unable to access server.js');
      });

  }, []);

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    document.body.classList.toggle('dark-mode', newDarkMode);
    localStorage.setItem('darkMode', newDarkMode);
  };

  return (
    <div className={`dashboard-container ${darkMode ? 'dark' : ''}`}>
      <header className="dashboard-header">
        <div className="header-left">
          <button className="settings-btn" onClick={() => navigate('/dashboard/user-profile')}>
            <FaCog className="settings-icon" /> Settings
          </button>
        </div>
        <div className="header-center">
          <h2>User {user} </h2>
        </div>
        <div className="header-buttons">
          <button className="nav-button" onClick={() => navigate('/dashboard/weather-info')}>
            <FaCloudSun className="nav-icon" />  Weather
          </button>
          <button className="nav-button" onClick={() => navigate('/dashboard/recent-favourite')}>Search History</button>
          <button className="nav-button" onClick={() => navigate('/dashboard/about-us')}>About Us</button>
          <button className="nav-button dark-mode-btn" onClick={toggleDarkMode}>
            {darkMode ? <FaSun className="dark-mode-icon" /> : <FaMoon className="dark-mode-icon" />}
            <span className="dark-mode-text">{darkMode ? 'Light' : 'Dark'}</span>
          </button>
        </div>
      </header><br/>
      <main className="dashboard-main">
        <div className="news-alert-section">
          <h2>News & Alerts</h2>
          <div className="alert">
            <h4>Severe Thunderstorm Warning</h4>
            <p>A severe thunderstorm warning has been issued for the following areas: Downtown, Northside, and West End. Please take shelter immediately.</p>
          </div>
          <div className="news">
            <h4>Weather Update</h4>
            <p>Expect sunny weather throughout the week with temperatures ranging from 25°C to 30°C. Perfect weather for outdoor activities!</p>
          </div>
          <div className="alert">
            <h4>Flood Warning</h4>
            <p>Heavy rains have caused water levels to rise. A flood warning is in effect for the riverfront areas. Evacuate immediately if you are in these areas.</p>
          </div>
        </div>
      </main><br/>
      <footer className="dashboard-footer">
        <h4>&copy; 2024 Admin Bijay Mishra. All rights reserved.</h4>
      </footer>
    </div>
  );
}

export default Dashboard;
