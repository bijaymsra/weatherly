import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './UserDetails.css';

const User = () => {
  const [fullName, setFullName] = useState('');
  const [country, setCountry] = useState('');
  const [age, setAge] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || ''; // Retrieve the email from navigation state

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage('');

    setTimeout(async () => {
      if (password !== confirmPassword) {
        setMessage('!!! Passwords do not match !!!');
        setIsLoading(false);
        return;
      }

      try {
        const response = await axios.post('http://localhost:5000/save-password', 
          { email, fullName, country, age, password }, { withCredentials: true });

        if (response.status === 201) {
          navigate('/Dashboard', { state: { email, fullName, age, country } });
        } else {
          setMessage('Unable to save user data.');
        }
      } catch (error) {
        setMessage(error.response?.data?.message || 'Something went wrong at backend. Fix it ...');
      } finally {
        setIsLoading(false);
      }
    }, 3000);
  };

  return (
    <div className="user-page">
      <div className="user-container">
        <form onSubmit={handleSubmit}>
          <h1>! Identity Verified Successfully !</h1>
          <h3>Before Dashboard, Let's fill some Details</h3>
          
          <div className="form-group">
            <label>Full Name:</label>
            <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Country:</label>
            <input type="text" value={country} onChange={(e) => setCountry(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>Age:</label>
            <input type="number" value={age} onChange={(e) => setAge(e.target.value)} required />
          </div>

          <div className="form-group">
            <label>New Password:</label>
            <div className="show-password-container">
              <input type={passwordVisible ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required />
              <button type="button" className="toggle-password" onClick={() => setPasswordVisible(!passwordVisible)}>
                {passwordVisible ? 'hide password' : 'show password'}
              </button>
            </div>
          </div>

          <div className="form-group">
            <label>Re-enter Password:</label>
            <input type={passwordVisible ? 'text' : 'password'} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
          </div>

          {message && <p className="error-message">{message}</p>}

          <button type="submit" className="proceed" disabled={isLoading}>
            {isLoading ? 'Please wait a moment...' : 'Proceed'}
          </button>
        </form>

        <a href="/login" className="back-link">Go back</a>
      </div>
    </div>
  );
};

export default User;
