import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Dashboard.css'; 

function City() {
    const [weather, setWeather] = useState(null);
    const [error, setError] = useState('');
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get('http://localhost:5000/api/sessions', { withCredentials: true })
            .then(response => {
                console.log('Session Data:', response.data);
                setEmail(response.data.email);
            })
            .catch(error => {
                console.error('Error fetching session data:', error);
            });
    }, []);

    useEffect(() => {
        if (email) {
            const fetchCity = async () => {
                try {
                    await axios.post('http://localhost:5000/das/get-city', { email });
                    setError('');
                } catch (err) {
                    setError('Unable to fetch City Details');
                }
            };
            fetchCity();
        }
    }, [email]);

    useEffect(() => {
        const fetchWeather = async () => {
            try {
                const weatherResponse = await axios.post('http://localhost:5000/das/city-details');
                setWeather(weatherResponse.data);
                setError('');
            } catch (err) {
                setError('!!! Unable to fetch weather data for the selected location !!!');
                setWeather(null);
            } finally {
                setLoading(false);
            }
        };

        const timeoutId = setTimeout(fetchWeather, 3000);
        return () => clearTimeout(timeoutId);
    }, []);

    const renderIcon = (condition) => {
        switch (condition.toLowerCase()) {
            case 'clear':
                return '☀️';
            case 'rain':
                return '🌧️';
            case 'clouds':
                return '☁️';
            case 'snow':
                return '❄️';
            case 'thunderstorm':
                return '⛈️';
            default:
                return '🌤️';
        }
    };

    return (
        <div className='bg'>
            {loading ? (
                <div className="loading-info">
                    <h2>Welcome to Weatherly!</h2>
                    <p>Weatherly provides real-time weather updates for your chosen location. Get accurate temperature, humidity, wind speed, and more!</p>
                    <p>Preparing your personalized weather report...</p>
                </div>
            ) : weather ? (

                <div className="city-info">
                    <h2>Weather in {weather.city}</h2>
                    <div className="city-main-info">
                        <div className="city-item">
                            <h4>{renderIcon('Temperature')} Temperature: {weather.temperature}°C</h4>
                            <h5>(Feels like: {weather.feelsLike}°C)</h5>
                            <p>Ideal range: 18°C to 24°C. Ensure to stay hydrated if it's hotter, and dress warmly if colder.</p>
                        </div>
                        <div className="city-item">
                            <h4>{renderIcon('Humidity')} Humidity: {weather.humidity}%</h4>
                            <p>Humidity plays a significant role in how we perceive temperature. Higher humidity can make the temperature feel warmer. Optimal range: 30%-50% for comfort.</p>
                        </div>
                        <div className="city-item">
                            <h4>{renderIcon('Pressure')} Pressure: {weather.pressure} hPa</h4>
                            <p>Pressure indicates the weight of the air above you. High pressure generally means fair weather, while low pressure can lead to storms.</p>
                        </div>
                        <div className="city-item">
                            <h4>{renderIcon(weather.condition)} Condition: {weather.condition}</h4>
                            <p>Currently experiencing {weather.condition}, which may affect visibility and overall comfort. Take necessary precautions.</p>
                        </div>
                        <div className="city-item">
                            <h4>{renderIcon('Wind Speed')} Wind Speed: {weather.windSpeed} m/s</h4>
                            <h5>Gusts: {weather.windGust ? `${weather.windGust} m/s` : 'N/A'}</h5>
                            <p>Wind speed affects how cold or warm you feel. Gusty winds can create a chilling effect, even in moderate temperatures. Wind chill can make it feel cooler than the actual temperature.</p>
                        </div>
                        <div className="city-item">
                            <h4>{renderIcon('Cloudiness')} Cloudiness: {weather.cloudiness}%</h4>
                            <p>Cloud cover affects sunlight and temperature. {weather.cloudiness}% cloudiness indicates a predominantly overcast sky.</p>
                        </div>
                        <div className="city-item">
                            <h4>{renderIcon('Visibility')} Visibility: {weather.visibility} meters</h4>
                            <p>Reduced visibility can impact travel and outdoor activities. Ensure you take necessary precautions when driving or navigating.</p>
                        </div>
                        <div className="city-item">
                            <h4>🌍 Latitude: {weather.lat}, Longitude: {weather.lon}</h4>
                            <p>Geographical coordinates of the location. These can help in pinpointing the exact area of the weather conditions.</p>
                        </div>
                        <div className="city-item">
                            <h4>🌅 Sunrise: {new Date(weather.sunrise * 1000).toLocaleTimeString()}</h4>
                        </div>
                        <div className="city-item">
                            <h4>🌇 Sunset: {new Date(weather.sunset * 1000).toLocaleTimeString()}</h4>
                        </div>
                    </div>
                </div>
            ) : (
                <p className="error-message">{error}</p>
            )}
        </div>
    );
}

export default City;
