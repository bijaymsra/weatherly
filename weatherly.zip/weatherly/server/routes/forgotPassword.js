const express = require('express');
const router = express.Router();
const db = require('../database');
const nodemailer = require('nodemailer');

router.post('/', (req, res) => {
  const { email } = req.body;

  const query = 'SELECT * FROM user WHERE email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      return res.status(500).json({ message: 'Error querying the database.' });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: 'Email not found.' });
    }

    const code = Math.floor(1000 + Math.random() * 9000).toString();
    const updateQuery = 'UPDATE user SET reset_code = ? WHERE email = ?';
    db.query(updateQuery, [code, email], (err) => {
      if (err) {
        console.error('Database update error:', err);
        return res.status(500).json({ message: 'Error updating the database.' });
      }

      const transporter = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
          user: '3techsoul@gmail.com',
          pass: 'tcul vobg scke mkuu',
        },
      });

      const mailOptions = {
        from: '3techsoul@gmail.com',
        to: email,
        subject: 'Password Reset Code for Weatherly',
        text: `Send by Admin. Your password reset code is: ${code}.`,
      };

      transporter.sendMail(mailOptions, (error) => {
        if (error) {
          console.error('Error sending email:', error);
          return res.status(500).json({ message: 'Error sending email.' });
        }

        res.status(200).json({ message: 'Kindly check your email.' });
      });
    });
  });
});

module.exports = router;
