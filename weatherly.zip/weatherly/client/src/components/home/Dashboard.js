import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FaSun, FaMoon, FaCog, FaCloudSun } from 'react-icons/fa';
import { FaStar } from 'react-icons/fa';
import { FaLinkedin, FaInstagram, FaTwitter } from 'react-icons/fa';
import './Dashboard.css';
import CityDetails from './City_Details';

function Dashboard() {
  const navigate = useNavigate();
  const [darkMode, setDarkMode] = useState(false);
  const [user, setUser] = useState('');
  const [feedbacks, setFeedbacks] = useState([]);
  const [topUsers, setTopUsers] = useState([]);
  // const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/api/session', { withCredentials: true })
      .then(response => {
        if (response.status === 200) {
          setUser(response.data.name);
          const savedDarkMode = localStorage.getItem('darkMode') === 'true';
          setDarkMode(savedDarkMode);
          document.body.classList.toggle('dark-mode', savedDarkMode);
        } else {
          throw new Error('Failed to fetch session data');
        }
      })
      .catch(error => {
        console.error('Unable to access server.js');
      });
  }, []);


  useEffect(() => {
    axios.get('http://localhost:5000/user-involvement/feedbacks')
      .then(response => setFeedbacks(response.data))
      .catch(error => setError('Failed to load feedbacks'));

    axios.get('http://localhost:5000/user-involvement/top-users')
      .then(response => setTopUsers(response.data))
      .catch(error => setError('Failed to load top users'));
  }, []);

  const ratings = [
    { category: 'Ease of Use', score: 4.8 },
    { category: 'Performance', score: 4.7 },
    { category: 'Customer Support', score: 4.9 },
  ];

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    document.body.classList.toggle('dark-mode', newDarkMode);
    localStorage.setItem('darkMode', newDarkMode);
  };

  return (
    <div className={`dashboard-container ${darkMode ? 'dark' : ''}`}>
      
      <header className="dashboard-header">
        <div className="header-left">
          <button className="settings-btn" onClick={() => navigate('/dashboard/user-profile')}>
            <FaCog className="settings-icon" /> Settings
          </button>
        </div>
        <div className="header-center">
          <h2>Hi, {user}</h2>
        </div>
        <div className="header-buttons">
          <button className="nav-button" onClick={() => navigate('/dashboard/weather-info')}>
            <FaCloudSun className="nav-icon" />  Weather
          </button>
          <button className="nav-button" onClick={() => navigate('/dashboard/recent-favourite')}>Search History</button>
          <button className="nav-button" onClick={() => navigate('/dashboard/about-us')}>About Us</button>
          <button className="nav-button dark-mode-btn" onClick={toggleDarkMode}>
            {darkMode ? <FaSun className="dark-mode-icon" /> : <FaMoon className="dark-mode-icon" />}
            <span className="dark-mode-text">{darkMode ? 'Light' : 'Dark'}</span>
          </button>
        </div>
      </header><br/>

      <CityDetails />


      <main className="dashboard-main">
        <div className="news-alert-section">
          <center><h2>News & Alerts</h2></center>
          <div className="alert">
            <h4>Severe Thunderstorm Warning</h4>
            <p>A severe thunderstorm warning has been issued for the following areas: Downtown, Northside, and West End. Please take shelter immediately.</p>
          </div>
          <div className="news">
            <h4>Weather Update</h4>
            <p>Expect sunny weather throughout the week with temperatures ranging from 25°C to 30°C. Perfect weather for outdoor activities!</p>
          </div>
          <div className="alert">
            <h4>Flood Warning</h4>
            <p>Heavy rains have caused water levels to rise. A flood warning is in effect for the riverfront areas. Evacuate immediately if you are in these areas.</p>
          </div>
        </div>
      </main><br/>


      <div className="user-involvement-section">
        <h2>Our Top Users</h2>
        <div className="top-users">
          {error ? <p>{error}</p> : (
            topUsers.length > 0 ? (
              topUsers.map((user, index) => (
                <div key={index} className="user-item">
                  <p><strong>&nbsp;Mr/Mrs. &nbsp;{user.userName}</strong></p>
                  <p>&nbsp;Total Searches: {user.searchCount}</p>
                </div>
              ))
            ) : (
              <p>No user involvement data available.</p>
            )
          )}
        </div>
      </div>



      <div className="feedback-section">
        <h2>Users Feedback</h2>
        {error ? <p>{error}</p> : (
          feedbacks.length > 0 ? (
            feedbacks.map((feedback, index) => (
              <div key={index} className="feedback-item">
                <p><strong>Mr/Mrs. &nbsp;{feedback.name}</strong></p>
                <p><strong>Date: {new Date(feedback.time_stamp).toLocaleDateString()}</strong></p>
                <h3><center><strong>{feedback.feedback}</strong></center></h3>
              </div>
            ))
          ) : (
            <p>No feedback available.</p>
          )
        )}
      </div>
      <div/>


      <div className="why-us-section">
        <h2>Why Us</h2>
        <div className="ratings">
          {ratings.map((rating, index) => (
            <div key={index} className="rating-item">
              <FaStar className="star-icon" />
              <div className="rating-details">
                <p className="rating-category">{rating.category}</p>
                <p className="rating-score">{rating.score}/5</p>
              </div>
            </div>
          ))}
        </div>
          </div>



      <div className="dash-contact-links">
                <h2 className="about-subheading">Contact Us</h2>
                <p>Feel free to reach out to us on social media:</p>
                <div className="dash-social-icons">
                    <a href="https://www.linkedin.com/in/bijaymsra" target="_blank" rel="noopener noreferrer">
                        <FaLinkedin size={30} />
                    </a>
                    <a href="https://www.instagram.com/bijaymsra" target="_blank" rel="noopener noreferrer">
                        <FaInstagram size={30} />
                    </a>
                    <a href="https://x.com/bijaymsra" target="_blank" rel="noopener noreferrer">
                        <FaTwitter size={30} />
                    </a>
                </div>
                <p>Or send us an email at: <a href="mailto:bm.bijaymishra@gmail.com">bm.bijaymishra@gmail.com</a></p>

            </div>

      <footer className="dashboard-footer">
        <h4>&copy; 2024 All rights reserved.</h4>
      </footer>
    </div>

  );
}
export default Dashboard;
