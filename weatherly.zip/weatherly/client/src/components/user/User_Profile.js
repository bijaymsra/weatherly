import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './User_Profile.css';

const User_Profile = () => {
  const [userDetails, setUserDetails] = useState({});
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Add a class to the body element when the component mounts
    document.body.classList.add('user-profile-page');

    // Remove the class from the body element when the component unmounts
    return () => {
      document.body.classList.remove('user-profile-page');
    };
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/user/details', { withCredentials: true });
        setUserDetails(response.data);
      } catch (err) {
        console.error(err);
        setError('Oops, No Data Found!');
      }
    };

    fetchData();
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:5000/user/logout', {}, { withCredentials: true });
      // Clear localStorage and navigate to login page
      localStorage.clear();
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  return (
    <div className="user-profile-container">
      {/* Back button */}
      <div className="back-button-container">
        <button className="back-button" onClick={() => navigate(-1)}>&#8592; Back</button>
      </div>

      {userDetails && (
        <div className="user-details">
          <h2 className="user-details-heading">Your Personal Details</h2>
          <div className="detail">
            <strong>Full Name:</strong> <span>Mr/Mrs. {userDetails.full_name}</span>
          </div>
          <div className="detail">
            <strong>Email:</strong> <span>{userDetails.email}</span>
          </div>
          <div className="detail">
            <strong>Password:</strong> <span>********</span>
          </div>
          <div className="detail">
          <strong>Age:</strong> <span>{userDetails.age} {userDetails.age === 1 ? 'year' : 'years'}</span>
          </div>
          <div className="detail">
            <strong>Country:</strong> <span>{userDetails.country}, {userDetails.city}</span>
          </div>
          <div className="detail">
            <strong>Enrollment Date:</strong> <span>{new Date(userDetails.time_stamp).toLocaleDateString()}</span>
          </div>
          {/* Logout button */}
          <div className="logout-button-container">
            <button className="logout-button" onClick={handleLogout}>Logout</button>
          </div>
        </div>
      )}
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default User_Profile;
