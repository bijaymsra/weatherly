import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './About_Us.css';

function About_Us() {
    const [name, setName] = useState('');
    const [currentAddress, setCurrentAddress] = useState('');
    const [contactNo, setContactNo] = useState('');
    const [feedback, setFeedback] = useState('');
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(''); // State for loading message
    const navigate = useNavigate();


        useEffect(() => {
        // Add a class to the body element when the component mounts
        document.body.classList.add('about-us-page');

        // Remove the class from the body element when the component unmounts
        return () => {
            document.body.classList.remove('about-us-page');
        };
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setLoading('Submitting...'); // Set loading message when form is submitted

        setTimeout(async () => {
            try {
                const response = await axios.post('http://localhost:5000/about', { name, currentAddress, contactNo, feedback }, { withCredentials: true });

                if (response.status === 201) {
                    setMessage('Feedback submitted successfully!');
                    setName('');
                    setCurrentAddress('');
                    setContactNo('');
                    setFeedback('');
                    setTimeout(() => {
                        setMessage('');
                    }, 3000); // Message disappears after 3 seconds
                } else {
                    setMessage('Unable to save feedback message.');
                }
            } catch (error) {
                setMessage(error.response?.data?.message || 'Something went wrong at backend. Fix it ...');
            } finally {
                setLoading(''); // Clear loading message after submission
            }
        }, 1000);
    };

    return (
        <div className="about-us-container">
            <div className="admin-info">
                <div className="back-button-container">
                    {/* Back button */}
                    <button className="back-button" onClick={() => navigate(-1)}>&#8592; Back</button>
                </div>

                <h2 className="about-subheading">Admin Details</h2>
                <p className="about-subheading"><strong>Name:</strong> Bijay Kumar Mishra</p>
                <p className="about-subheading"><strong>Contact No.:</strong> 8810862625</p>
                <p className="about-subheading"><strong>Email:</strong> <a href="mailto:bm.bijaymishra@gmail.com">bm.bijaymishra@gmail.com</a></p>
            </div>
            <div className="vision">
                <h2 className="about-subheading">Our Vision</h2>
                <p className="about-subheading">Our mission is to provide accurate and timely weather updates to help people plan their day and stay safe. We aim to use the latest technology to deliver real-time weather forecasts and alerts, ensuring you are always informed about the weather conditions in your area.</p>
                <p className="about-subheading">We envision a world where everyone has access to reliable weather information, helping communities to prepare and respond to weather-related events more effectively.</p>
            </div>
            <div className="feedback-form">
                <h2 className="about-subheading">Feedback</h2>
                {/* Feedback message */}
                {message && <p className="feedback-message">{message}</p>}
                <form onSubmit={handleSubmit}>
                    <label>
                        <p className="about-subheading">Name:</p>
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder='~' required />
                    </label>
                    <label>
                        <p className="about-subheading">Current Address:</p>
                        <input type="text" value={currentAddress} onChange={(e) => setCurrentAddress(e.target.value)} required />
                    </label>
                    <label>
                        <p className="about-subheading">Contact No:</p>
                        <input type="number" value={contactNo} onChange={(e) => setContactNo(e.target.value)} required />
                    </label>
                    <label>
                       <p className="about-subheading">Message:</p> 
                        <textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder='feedback here...' required></textarea>
                    </label>
                    <button type="submit">Submit</button>
                    {/* Submitting message */}
                    {loading && <p className="loading-message">{loading}</p>} {/* Display loading message */}
                </form>
            </div>
            <div className="contact-links">
                <h2 className="about-subheading">Contact Us</h2>
                <p className="about-subheading">Feel free to reach out to us on social media:</p>
                <a href="https://www.linkedin.com/in/bijaymsra" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                <a href="https://www.instagram.com/bijaymsra" target="_blank" rel="noopener noreferrer">Instagram</a>
                <a href="https://x.com/bijaymsra" target="_blank" rel="noopener noreferrer">Twitter</a>
                <p className="about-subheading">Or send us an email at: <a href="mailto:bm.bijaymishra@gmail.com">bm.bijaymishra@gmail.com</a></p>
            </div>
        </div>
    );
}

export default About_Us;
