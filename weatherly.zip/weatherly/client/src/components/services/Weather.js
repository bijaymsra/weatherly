import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { useLocation, useNavigate } from 'react-router-dom';
import './Weather.css';

const customIcon = new L.Icon({
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const LocationMarker = ({ position }) => (
  position ? (
    <Marker position={position} icon={customIcon}>
      <Popup>{position.lat.toFixed(2)}, {position.lng.toFixed(2)}</Popup>
    </Marker>
  ) : null
);

const MapClickHandler = ({ setPosition, fetchWeather }) => {
  useMapEvents({
    click: (e) => {
      const { lat, lng } = e.latlng;
      setPosition({ lat, lng });
      fetchWeather(lat, lng);
    }
  });
  return null;
};

const ZoomToLocation = ({ position }) => {
  const map = useMap();
  if (position) {
    map.setView([position.lat, position.lng], 10);
  }
  return null;
};

function Weather() {
  const [city, setCity] = useState('');
  const location = useLocation();
  const email = location.state?.email || '';
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');
  const [position, setPosition] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();


  useEffect(() => {
    // Add a class to the body element when the component mounts
    document.body.classList.add('weather-page');

    // Remove the class from the body element when the component unmounts
    return () => {
        document.body.classList.remove('weather-page');
    };
}, []);

  const fetchWeather = async (lat, lon) => {
    setLoading(true);
    try {
      const weatherResponse = await axios.post('http://localhost:5000/weather', { lat, lon });
      setWeather(weatherResponse.data);
      setError('');
    } catch (err) {
      setError('!!! Unable to fetch weather data for the selected location !!!');
      setWeather(null);
    } finally {
      setLoading(false);
    }
  };

  const saveWeather = async (lat, lon, email) => {
    try {
      const response = await axios.post('http://localhost:5000/weather/save', { city, lat, lon, email }, { withCredentials: true });
      if (response.status === 201) {
        console.log('Weather data saved successfully.');
      }
    } catch (error) {
      console.error('Error saving weather data:', error);
    }
  };

  const handleCitySearch = async (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(async () => {
      try {
        const geoResponse = await axios.get(`https://nominatim.openstreetmap.org/search`, {
          params: {
            q: city,
            format: 'json',
            limit: 1
          }
        });

        if (geoResponse.data.length === 0) {
          setError('!!! No results found for the provided city name !!!');
          setWeather(null);
          setLoading(false);
          return;
        }

        const { lat, lon } = geoResponse.data[0];
        setPosition({ lat: parseFloat(lat), lng: parseFloat(lon) });
        await fetchWeather(parseFloat(lat), parseFloat(lon));
        saveWeather(lat, lon, email);
      } catch (err) {
        setError('!!! Please provide a valid name ~ Enter again !!!');
        setWeather(null);
        setLoading(false);
      }
    }, 1000);
  };

  return (
    <div>
      <div className="weather-container">
      <div className="back-button-container">
        <button className="back-button" onClick={() => navigate(-1)}>&#8592; Back</button>
      </div >
      <center>
        <h1>Weatherly’s Dynamic Weather Dashboard</h1>
        <h5>Note: May show closest city if same not found...</h5><br/><br/>
        <form onSubmit={handleCitySearch}>
          <div className="input-container">
            <input type="text" placeholder="type city name here..." value={city} onChange={(e) => setCity(e.target.value)} required />
            <button className='search-btn' type="submit">Search</button>
          </div>
        </form>
        </center>
        </div>
        

        {loading && <h6 className="loading-message">Wait a moment...</h6>}
        {error && <p className="error-message">{error}</p>}
        {weather && !loading && (
          <div className="weather-info">
            <h2>Weather in {weather.city}</h2>
            <div className="weather-main-info">
              <div className="weather-item">
                <h4>Temperature: {weather.temperature}°C</h4>
              </div>
              <div className="weather-item">
                <h4>Humidity: {weather.humidity}%</h4>
              </div>
              <div className="weather-item">
                <h4>Condition: {weather.condition}</h4>
              </div>
            </div>
          </div>
        )}

        <div className="map-container">
          <MapContainer center={position || [20.5937, 78.9629]} zoom={4} scrollWheelZoom={true} style={{ height: '330px', width: '97%', borderRadius: '10px', marginLeft:'20px' }}>
            <TileLayer
              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            />
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
              opacity={0.5}
            />
            <LocationMarker position={position} />
            <MapClickHandler setPosition={setPosition} fetchWeather={fetchWeather} />
            <ZoomToLocation position={position} />
          </MapContainer>
        </div>

    </div>
  );
}

export default Weather;


