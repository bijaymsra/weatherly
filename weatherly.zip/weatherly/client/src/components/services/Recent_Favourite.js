import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Recent_Favourite.css';

const Recent_Favourite = () => {
  const [favoriteCity, setFavoriteCity] = useState('');
  const [recentSearches, setRecentSearches] = useState([]);
  const [error, setError] = useState('');
  const [user, setUser] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const favoriteResponse = await axios.get('http://localhost:5000/recent/city', { withCredentials: true });
        setFavoriteCity(favoriteResponse.data.city);

        const searchResponse = await axios.get('http://localhost:5000/recent/search', { withCredentials: true });
        setRecentSearches(searchResponse.data);
      } catch (err) {
        console.error(err);
        setError('Oops, No Data Found!');
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    document.body.classList.add('weather-recent-page');
    return () => {
      document.body.classList.remove('weather-recent-page');
    };
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/api/session', { withCredentials: true })
      .then(response => {
        if (response.status === 200) {
          setUser(response.data.name);
        } else {
          throw new Error('Failed to fetch session data');
        }
      })
      .catch(error => {
        console.error('Unable to access server.js');
      });
  }, []);

  return (
    <div className="recent-favourite-container">
      <div className="back-button-container">
        <button className="back-button" onClick={() => navigate(-1)}>&#8592; Back</button>
      </div>
      {favoriteCity && <p className="city-infos">{user}'s favorite city is {favoriteCity}</p>}
      {error && <p className="error">{error}</p>}
      {recentSearches.length > 0 && (
        <>
          <h2 className="recent-search-heading">Search History</h2>
          <ul className="recent-searches">
            {recentSearches.map((search, index) => (
              <li key={index} className="search-item">
                <div className="search-detail"><strong>City:</strong> <span>{search.city}</span></div>
                <div className="search-detail"><strong>Temperature:</strong> <span>{search.temperature}°C</span></div>
                <div className="search-detail"><strong>Visibility:</strong> <span>{search.visibility} km</span></div>
                <div className="search-detail"><strong>Condition:</strong> <span>{search.condition}</span></div>
                <div className="search-detail"><strong>Humidity:</strong> <span>{search.humidity}%</span></div>
                <div className="search-detail"><strong>Time:</strong> <span>{new Date(search.time_stamp).toLocaleString()}</span></div>
              </li>
            ))}
          </ul>
        </>
      )}
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default Recent_Favourite;
