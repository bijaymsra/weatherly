import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './Verify.css';

const Verify = () => {
  const [code, setCode] = useState('');
  const [message, setMessage] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || '';

  const handleRequestCode = async (e) => {
    e.preventDefault();
    setIsRegenerating(true);
    setMessage('');

    try {
      const response = await axios.post('http://localhost:5000/verify', { email });
      setMessage(response.data.message);
      if (response.status === 200) {
        navigate('/login/verify', { state: { email } });
      }
    } catch (error) {
      setMessage(error.response?.data?.message || 'Error requesting code');
    } finally {
      setIsRegenerating(false);
    }
  };

  const handleVerifyCode = async (e) => {
    e.preventDefault();
    setIsVerifying(true);
    setMessage('');

    setTimeout(async () => {
      try {
        const response = await axios.post('http://localhost:5000/otp-verify', { email, code });
        setMessage(response.data.message);
        if (response.status === 200) {
          navigate('/login/verify/user-details', { state: { email } });
        }
      } catch (error) {
        setMessage('Oops, wrong otp entered');
      } finally {
        setIsVerifying(false);
      }
    }, 2000);
  };

  return (
    <div className="verify-page">
      <div className="verify-container">
        <form onSubmit={handleVerifyCode}>
          <h1>!!! Please Verify Your Identity !!!</h1>
          <p>Check ~  "{email}" for Otp Verification</p>
          <div>
            <label>Enter OTP:</label>
            <input type="text" value={code} onChange={(e) => setCode(e.target.value)} required disabled={isVerifying} />
          </div>
          <button type="submit" disabled={isVerifying}>
            {isVerifying ? 'Verifying...' : 'Verify'}
          </button>
          {isVerifying && <p className="loading-message">Please wait...</p>}
          {message && <p className={message.includes('Oops') ? 'error-message' : 'success-message'}>{message}</p>}
        </form>
        <form onSubmit={handleRequestCode}>
          <button type="submit" disabled={isRegenerating}>
            {isRegenerating ? 'Generating...' : 'Regenerate OTP'}
          </button>
          {isRegenerating && <p className="loading-message">Wait a moment...</p>}
          {/* {message && <p className={message.includes('Error') ? 'error-message' : 'success-message'}>{message}</p>} */}
        </form>
        <Link to="/login" className="back-link">Go Back</Link>
      </div>
    </div>
  );
};

export default Verify;
