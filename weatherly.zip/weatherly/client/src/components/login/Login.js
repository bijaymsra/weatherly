import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading1, setIsLoading1] = useState(false);
  const [isLoading3, setIsLoading3] = useState(false);
  const [isLoading4, setIsLoading4] = useState(false);
  const [isDisable1, setIsDisable1] = useState(false);
  const [isForgotVisible, setIsForgotVisible] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const navigate = useNavigate();

  const handleRequestCode = async (e) => {
    e.preventDefault();
    setIsLoading1(true);
    setMessage('');
    setErrorMessage('');

    setTimeout(async () => {
      try {
        const response = await axios.post('http://localhost:5000/verify', { email }, { withCredentials: true });
        // setMessage('Welcome! Please enter your password.');
        if (response.status === 200) {
          setIsPasswordVisible(true);
          setIsDisable1(true);
        }
      } catch (error) {
        if (error.response && error.response.status === 404) {
          navigate('/login/verify', { state: { email } });
        }
        setErrorMessage(error.response?.data?.message || 'Error requesting code');
      } finally {
        setIsLoading1(false);
      }
    }, 1000);
  };

  const goToForgotPage = async (e) => {
    e.preventDefault();
    setMessage('');
    setIsLoading4(true);

    try {
      const response = await axios.post('http://localhost:5000/verify/forgot', { email }, { withCredentials: true });
      setMessage(response.data.message);
      if (response.status === 200) {
        navigate('/login/forgot-password', { state: { email } });
      }
    } catch (error) {
      setErrorMessage(error.response?.data?.message || 'Error requesting code');
    } finally {
      setIsLoading4(false);
    }
  };

  const handleVerifyPassword = async (e) => {
    e.preventDefault();
    setIsLoading3(true);
    setMessage('');
    setErrorMessage('');

    setTimeout(async () => {
      try {
        const response = await axios.post('http://localhost:5000/match-password', { email, password }, { withCredentials: true });
        if (response.status === 200) {
          navigate('/dashboard', { state: { email } });
        }
      } catch (error) {
        setErrorMessage('Wrong password. Try later.');
        setIsForgotVisible(true);
      } finally {
        setIsLoading3(false);
      }
    }, 2000);
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <center>
          <form onSubmit={handleRequestCode}>
            <h1> Weatherly  Welcome's <span className="emoji">👋</span> </h1> 
            <div>
              <label>Gmail Account:</label>
              <input type="email" placeholder='example@gmail.com' value={email} onChange={(e) => setEmail(e.target.value)} required disabled={isDisable1} />
              <button type="submit" disabled={isDisable1}>
                {isLoading1 ? 'searching...' : 'Click to Verify'}
              </button>
              {isLoading1 && <p className="loading-message">wait a moment...</p>}
              {message && <p className="success-message">{message}</p>}
            </div>
          </form>

          {isPasswordVisible && (
            <form onSubmit={handleVerifyPassword} className='veri-password'>
              <div style={{ marginTop: '20px' }}>
                <label>Enter Password:</label>

               

                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required disabled={isLoading3} />
                <button type="submit" disabled={isLoading3}>
                  {isLoading3 ? 'Verifying Credentials...' : 'Login'}
                </button>
                
              </div>
              {errorMessage && <p className="error">{errorMessage}</p>}
            </form>
            
          )}

          {isForgotVisible && (
            <form onSubmit={goToForgotPage}>
              <button type="submit" disabled={isLoading4}>
                {isLoading4 ? 'Sending otp...' : 'Forgot Password?'}
              </button>
            </form>
          )}
        </center>
      </div>
    </div>
  );
};

export default Login;
