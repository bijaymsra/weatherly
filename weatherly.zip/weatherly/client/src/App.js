import {BrowserRouter as Router, Route , Routes} from 'react-router-dom';
import LogIn from './components/login/Login';
import Dashboard from "./components/home/Dashboard";
import Forgot from './components/login/Forgot';
import Verify from './components/login/Verify';
import User from './components/login/UserDetails';
import Weather from './components/services/Weather';
import AboutUs from './components/about/About_Us';
import UserProfile from './components/user/User_Profile';
import RecentFavourite from './components/services/Recent_Favourite';

function App() {
  return (
        <Router>
          <div>

            <Routes> 

              <Route path='/' element={ <LogIn/> } />
              <Route path='/login' element={ <LogIn/> } />
              <Route path='/login/verify/user-details' element={ <User/> } />
              <Route path='/login/verify' element={ <Verify/> } />
              <Route path='/dashboard' element={ <Dashboard/> } />
              <Route path='/login/forgot-password' element={ <Forgot/> } />
              <Route path='/dashboard/weather-info' element={ <Weather/> } />
              <Route path='/dashboard/about-us' element={ <AboutUs/> } />
              <Route path='/dashboard/user-profile' element={ <UserProfile/> } />
              <Route path='/dashboard/recent-favourite' element={ <RecentFavourite/> } />

            </Routes>

            
          </div>
        </Router>
  );
}

export default App;
